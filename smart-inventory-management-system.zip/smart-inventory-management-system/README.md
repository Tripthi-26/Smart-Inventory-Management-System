# Smart Inventory Management System

Full Stack Inventory Management System built with Node.js, Express, SQLite, and vanilla JS (Tailwind via CDN, Chart.js, SweetAlert2).

## Setup

```bash
npm install
npm start
```

Then open: http://localhost:3000

## Default Login

- Username: `admin`
- Password: `admin123`

## Project Structure

```
client/      # Frontend (HTML/CSS/JS)
server/      # Express API + SQLite
  controllers/
  routes/
  middleware/
  config/
  database/
  uploads/   # Uploaded product images
  server.js
```

## Features

Authentication, Dashboard with charts, Products (with image upload + auto barcode),
Suppliers, Sales, Orders, Returns, Restock, Inventory logs, Notifications, and
Reports (PDF/CSV export).
