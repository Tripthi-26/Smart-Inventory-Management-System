// Shared frontend utilities: API client, layout, sidebar
const API = (path, opts = {}) =>
  fetch('/api' + path, { credentials: 'include', ...opts })
    .then(async r => {
      const ct = r.headers.get('content-type') || '';
      const data = ct.includes('json') ? await r.json() : await r.text();
      if (!r.ok) throw new Error((data && data.error) || 'Request failed');
      return data;
    });

const APIForm = (path, formData, method = 'POST') =>
  fetch('/api' + path, { method, credentials: 'include', body: formData })
    .then(async r => {
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || 'Request failed');
      return data;
    });

function toast(icon, title) {
  Swal.fire({ toast: true, position: 'top-end', icon, title, showConfirmButton: false, timer: 2200 });
}

function sidebar(active) {
  const items = [
    ['Dashboard', '/dashboard.html'],
    ['Products',  '/products.html'],
    ['Suppliers', '/suppliers.html'],
    ['Sales',     '/sales.html'],
    ['Orders',    '/orders.html'],
    ['Returns',   '/returns.html'],
    ['Reports',   '/reports.html'],
  ];
  return `
    <aside class="w-60 bg-slate-900 text-slate-100 min-h-screen flex flex-col">
      <div class="p-4 text-lg font-bold border-b border-slate-700">📦 SIMS</div>
      <nav class="flex-1 p-2 space-y-1">
        ${items.map(([n, h]) => `
          <a href="${h}" class="sidebar-link block px-3 py-2 rounded hover:bg-slate-800 ${active===n?'active':''}">${n}</a>
        `).join('')}
      </nav>
      <button id="logoutBtn" class="m-2 px-3 py-2 rounded bg-red-600 hover:bg-red-700">Logout</button>
    </aside>`;
}

function layout(active, contentHtml) {
  document.body.innerHTML = `
    <div class="flex min-h-screen bg-slate-100">
      ${sidebar(active)}
      <main class="flex-1 p-6">${contentHtml}</main>
    </div>`;
  document.getElementById('logoutBtn').onclick = async () => {
    await API('/auth/logout');
    location.href = '/index.html';
  };
}

async function requireSession() {
  try { await API('/auth/me'); }
  catch { location.href = '/index.html'; }
}
