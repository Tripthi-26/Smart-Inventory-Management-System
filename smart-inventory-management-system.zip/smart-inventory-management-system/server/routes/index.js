const router = require('express').Router();
const requireAuth = require('../middleware/auth');
const upload = require('../middleware/upload');

const auth = require('../controllers/authController');
const products = require('../controllers/productController');
const suppliers = require('../controllers/supplierController');
const sales = require('../controllers/salesController');
const orders = require('../controllers/orderController');
const returns = require('../controllers/returnController');
const dashboard = require('../controllers/dashboardController');
const reports = require('../controllers/reportController');

// Auth
router.post('/auth/login', auth.login);
router.get('/auth/logout', auth.logout);
router.get('/auth/me', auth.me);

// Dashboard
router.get('/dashboard', requireAuth, dashboard.summary);
router.get('/notifications', requireAuth, dashboard.notifications);

// Products
router.get('/products', requireAuth, products.list);
router.get('/products/:id', requireAuth, products.get);
router.post('/products', requireAuth, upload.single('image'), products.create);
router.put('/products/:id', requireAuth, upload.single('image'), products.update);
router.delete('/products/:id', requireAuth, products.remove);
router.put('/products/restock/:id', requireAuth, products.restock);
router.get('/products/:id/barcode.png', requireAuth, products.barcodeImage);

// Suppliers
router.get('/suppliers', requireAuth, suppliers.list);
router.post('/suppliers', requireAuth, suppliers.create);
router.put('/suppliers/:id', requireAuth, suppliers.update);
router.delete('/suppliers/:id', requireAuth, suppliers.remove);

// Sales
router.get('/sales', requireAuth, sales.list);
router.post('/sales', requireAuth, sales.create);

// Orders
router.get('/orders', requireAuth, orders.list);
router.post('/orders', requireAuth, orders.create);
router.put('/orders/:id', requireAuth, orders.updateStatus);

// Returns
router.get('/returns', requireAuth, returns.list);
router.post('/returns', requireAuth, returns.create);
router.put('/returns/:id', requireAuth, returns.updateStatus);

// Reports
router.get('/reports/:type', requireAuth, reports.json);
router.get('/reports/:type/csv', requireAuth, reports.csv);
router.get('/reports/:type/pdf', requireAuth, reports.pdf);

module.exports = router;
