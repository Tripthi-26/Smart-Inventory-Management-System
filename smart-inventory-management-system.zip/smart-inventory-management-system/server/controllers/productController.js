const { db } = require('../database/db');

async function logInventory(productId, actionType, qty) {
  await db.runP(
    'INSERT INTO inventory_logs (product_id, action_type, quantity_changed) VALUES (?,?,?)',
    [productId, actionType, qty]
  );
}

async function notify(message) {
  await db.runP('INSERT INTO notifications (message) VALUES (?)', [message]);
}

function genBarcode() {
  // 12-digit numeric barcode (EAN-like)
  let s = '';
  for (let i = 0; i < 12; i++) s += Math.floor(Math.random() * 10);
  return s;
}

exports.list = async (_req, res) => {
  try {
    const rows = await db.allP(`
      SELECT p.*, s.name AS supplier_name
      FROM products p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      ORDER BY p.id DESC
    `);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.get = async (req, res) => {
  try {
    const row = await db.getP('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { name, description, category, price, quantity, threshold_value, supplier_id } = req.body;
    const image = req.file ? '/uploads/' + req.file.filename : null;
    const barcode = genBarcode();
    const r = await db.runP(
      `INSERT INTO products (name, description, category, price, quantity, threshold_value, supplier_id, barcode, image)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [name, description, category, parseFloat(price) || 0, parseInt(quantity) || 0,
       parseInt(threshold_value) || 5, supplier_id || null, barcode, image]
    );
    await logInventory(r.lastID, 'Added', parseInt(quantity) || 0);
    res.json({ success: true, id: r.lastID, barcode });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const existing = await db.getP('SELECT * FROM products WHERE id = ?', [id]);
    if (!existing) return res.status(404).json({ error: 'Not found' });
    const { name, description, category, price, quantity, threshold_value, supplier_id } = req.body;
    const image = req.file ? '/uploads/' + req.file.filename : existing.image;
    await db.runP(
      `UPDATE products SET name=?, description=?, category=?, price=?, quantity=?, threshold_value=?, supplier_id=?, image=?
       WHERE id=?`,
      [name, description, category, parseFloat(price) || 0, parseInt(quantity) || 0,
       parseInt(threshold_value) || 5, supplier_id || null, image, id]
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.remove = async (req, res) => {
  try {
    await db.runP('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.restock = async (req, res) => {
  try {
    const id = req.params.id;
    const qty = parseInt(req.body.quantity) || 0;
    if (qty <= 0) return res.status(400).json({ error: 'Quantity must be > 0' });
    await db.runP('UPDATE products SET quantity = quantity + ? WHERE id = ?', [qty, id]);
    await logInventory(id, 'Restocked', qty);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

// Barcode image (PNG)
exports.barcodeImage = async (req, res) => {
  try {
    const bwipjs = require('bwip-js');
    const p = await db.getP('SELECT barcode FROM products WHERE id = ?', [req.params.id]);
    if (!p || !p.barcode) return res.status(404).end();
    const png = await bwipjs.toBuffer({
      bcid: 'code128', text: p.barcode, scale: 3, height: 10, includetext: true, textxalign: 'center',
    });
    res.type('png').send(png);
  } catch (e) { res.status(500).json({ error: e.message }); }
};

// Internal helpers used by other controllers
exports._logInventory = logInventory;
exports._notify = notify;
