const { db } = require('../database/db');
const { _logInventory, _notify } = require('./productController');

exports.list = async (_req, res) => {
  try {
    res.json(await db.allP(`
      SELECT r.*, p.name AS product_name
      FROM returns r LEFT JOIN products p ON p.id = r.product_id
      ORDER BY r.id DESC
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { product_id, reason } = req.body;
    if (!product_id) return res.status(400).json({ error: 'product_id required' });
    const r = await db.runP(
      'INSERT INTO returns (product_id, reason) VALUES (?,?)',
      [product_id, reason]
    );
    await _notify(`New return request #${r.lastID}`);
    res.json({ success: true, id: r.lastID });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.updateStatus = async (req, res) => {
  try {
    const { refund_status } = req.body;
    const allowed = ['Pending', 'Approved', 'Rejected'];
    if (!allowed.includes(refund_status)) return res.status(400).json({ error: 'Invalid status' });
    const existing = await db.getP('SELECT * FROM returns WHERE id=?', [req.params.id]);
    if (!existing) return res.status(404).json({ error: 'Not found' });
    await db.runP('UPDATE returns SET refund_status=? WHERE id=?', [refund_status, req.params.id]);
    // If approved, return product to inventory
    if (refund_status === 'Approved' && existing.refund_status !== 'Approved') {
      await db.runP('UPDATE products SET quantity = quantity + 1 WHERE id=?', [existing.product_id]);
      await _logInventory(existing.product_id, 'Returned', 1);
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
