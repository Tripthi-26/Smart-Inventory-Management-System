const { db } = require('../database/db');
const { _logInventory, _notify } = require('./productController');

exports.list = async (_req, res) => {
  try {
    res.json(await db.allP(`
      SELECT s.*, p.name AS product_name
      FROM sales s LEFT JOIN products p ON p.id = s.product_id
      ORDER BY s.id DESC
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { product_id, customer_name, quantity } = req.body;
    const qty = parseInt(quantity) || 0;
    if (!product_id || qty <= 0) return res.status(400).json({ error: 'Invalid input' });
    const product = await db.getP('SELECT * FROM products WHERE id=?', [product_id]);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    if (product.quantity < qty) return res.status(400).json({ error: 'Insufficient stock' });
    const total = product.price * qty;
    const r = await db.runP(
      'INSERT INTO sales (product_id, customer_name, quantity, total_amount) VALUES (?,?,?,?)',
      [product_id, customer_name, qty, total]
    );
    await db.runP('UPDATE products SET quantity = quantity - ? WHERE id=?', [qty, product_id]);
    await _logInventory(product_id, 'Sold', qty);
    // Low stock alert
    const after = product.quantity - qty;
    if (after <= product.threshold_value) {
      await _notify(`Low stock alert: ${product.name} (${after} left)`);
    }
    res.json({ success: true, id: r.lastID, total });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
