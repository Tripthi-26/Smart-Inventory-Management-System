const { db } = require('../database/db');

exports.summary = async (_req, res) => {
  try {
    const totalProducts = (await db.getP('SELECT COUNT(*) AS c FROM products')).c;
    const totalSuppliers = (await db.getP('SELECT COUNT(*) AS c FROM suppliers')).c;
    const totalSales = (await db.getP('SELECT COUNT(*) AS c FROM sales')).c;
    const totalRevenue = (await db.getP('SELECT COALESCE(SUM(total_amount),0) AS s FROM sales')).s;

    // Sales over last 7 days
    const salesByDay = await db.allP(`
      SELECT DATE(sale_date) AS day, SUM(total_amount) AS revenue, COUNT(*) AS count
      FROM sales
      WHERE sale_date >= DATE('now','-6 day')
      GROUP BY DATE(sale_date)
      ORDER BY day
    `);

    // Category distribution
    const categories = await db.allP(`
      SELECT COALESCE(category,'Uncategorized') AS category, SUM(quantity) AS qty
      FROM products GROUP BY category
    `);

    // Low stock
    const lowStock = await db.allP(`
      SELECT * FROM products WHERE quantity <= threshold_value ORDER BY quantity ASC
    `);

    res.json({ totalProducts, totalSuppliers, totalSales, totalRevenue, salesByDay, categories, lowStock });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.notifications = async (_req, res) => {
  try {
    res.json(await db.allP('SELECT * FROM notifications ORDER BY id DESC LIMIT 50'));
  } catch (e) { res.status(500).json({ error: e.message }); }
};
