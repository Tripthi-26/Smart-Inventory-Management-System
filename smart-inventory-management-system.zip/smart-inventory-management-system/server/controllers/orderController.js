const { db } = require('../database/db');
const { _notify } = require('./productController');

exports.list = async (_req, res) => {
  try {
    res.json(await db.allP(`
      SELECT o.*, p.name AS product_name
      FROM orders o LEFT JOIN products p ON p.id = o.product_id
      ORDER BY o.id DESC
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { customer_name, product_id, quantity } = req.body;
    if (!customer_name || !product_id || !quantity) return res.status(400).json({ error: 'Missing fields' });
    const r = await db.runP(
      'INSERT INTO orders (customer_name, product_id, quantity) VALUES (?,?,?)',
      [customer_name, product_id, parseInt(quantity)]
    );
    await _notify(`New order #${r.lastID} from ${customer_name}`);
    res.json({ success: true, id: r.lastID });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.updateStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ['Pending', 'Shipped', 'Delivered', 'Cancelled'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await db.runP('UPDATE orders SET status=? WHERE id=?', [status, req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
