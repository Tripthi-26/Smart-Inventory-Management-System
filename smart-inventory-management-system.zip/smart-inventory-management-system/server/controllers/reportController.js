const { db } = require('../database/db');
const PDFDocument = require('pdfkit');
const { createObjectCsvStringifier } = require('csv-writer');

async function getData(type) {
  switch (type) {
    case 'low-stock':
      return {
        title: 'Low Stock Report',
        rows: await db.allP('SELECT id, name, category, quantity, threshold_value FROM products WHERE quantity <= threshold_value'),
        headers: [
          { id: 'id', title: 'ID' }, { id: 'name', title: 'Name' },
          { id: 'category', title: 'Category' }, { id: 'quantity', title: 'Qty' },
          { id: 'threshold_value', title: 'Threshold' },
        ],
      };
    case 'sales':
      return {
        title: 'Sales Report',
        rows: await db.allP(`
          SELECT p.name AS product, COUNT(s.id) AS sales_count, SUM(s.quantity) AS units, SUM(s.total_amount) AS revenue
          FROM sales s JOIN products p ON p.id = s.product_id GROUP BY s.product_id
        `),
        headers: [
          { id: 'product', title: 'Product' }, { id: 'sales_count', title: 'Sales' },
          { id: 'units', title: 'Units' }, { id: 'revenue', title: 'Revenue' },
        ],
      };
    case 'supplier-performance':
      return {
        title: 'Supplier Performance Report',
        rows: await db.allP(`
          SELECT s.name AS supplier, COUNT(p.id) AS products_supplied, COALESCE(SUM(p.quantity),0) AS total_stock
          FROM suppliers s LEFT JOIN products p ON p.supplier_id = s.id GROUP BY s.id
        `),
        headers: [
          { id: 'supplier', title: 'Supplier' }, { id: 'products_supplied', title: 'Products' },
          { id: 'total_stock', title: 'Total Stock' },
        ],
      };
    case 'inventory':
      return {
        title: 'Inventory Report',
        rows: await db.allP('SELECT id, name, category, quantity, price FROM products'),
        headers: [
          { id: 'id', title: 'ID' }, { id: 'name', title: 'Name' },
          { id: 'category', title: 'Category' }, { id: 'quantity', title: 'Qty' },
          { id: 'price', title: 'Price' },
        ],
      };
    default: return null;
  }
}

exports.json = async (req, res) => {
  const data = await getData(req.params.type);
  if (!data) return res.status(404).json({ error: 'Unknown report' });
  res.json(data);
};

exports.csv = async (req, res) => {
  const data = await getData(req.params.type);
  if (!data) return res.status(404).send('Unknown report');
  const stringifier = createObjectCsvStringifier({ header: data.headers });
  const csv = stringifier.getHeaderString() + stringifier.stringifyRecords(data.rows);
  res.type('text/csv').attachment(`${req.params.type}.csv`).send(csv);
};

exports.pdf = async (req, res) => {
  const data = await getData(req.params.type);
  if (!data) return res.status(404).send('Unknown report');
  const doc = new PDFDocument({ margin: 40 });
  res.type('application/pdf').attachment(`${req.params.type}.pdf`);
  doc.pipe(res);
  doc.fontSize(18).text(data.title, { align: 'center' }).moveDown();
  doc.fontSize(10);
  // Header
  doc.text(data.headers.map(h => h.title).join(' | '));
  doc.moveTo(40, doc.y).lineTo(555, doc.y).stroke().moveDown(0.3);
  data.rows.forEach(r => {
    doc.text(data.headers.map(h => String(r[h.id] ?? '')).join(' | '));
  });
  doc.end();
};
