const { db } = require('../database/db');

exports.list = async (_req, res) => {
  try { res.json(await db.allP('SELECT * FROM suppliers ORDER BY id DESC')); }
  catch (e) { res.status(500).json({ error: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { name, contact, email, address } = req.body;
    if (!name) return res.status(400).json({ error: 'Name required' });
    const r = await db.runP(
      'INSERT INTO suppliers (name, contact, email, address) VALUES (?,?,?,?)',
      [name, contact, email, address]
    );
    res.json({ success: true, id: r.lastID });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.update = async (req, res) => {
  try {
    const { name, contact, email, address } = req.body;
    await db.runP(
      'UPDATE suppliers SET name=?, contact=?, email=?, address=? WHERE id=?',
      [name, contact, email, address, req.params.id]
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.remove = async (req, res) => {
  try {
    await db.runP('DELETE FROM suppliers WHERE id=?', [req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
