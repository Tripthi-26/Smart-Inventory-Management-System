// Smart Inventory Management System — Express entry point
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const { PORT, SESSION_SECRET, UPLOAD_DIR } = require('./config/config');
const { init } = require('./database/db');
const apiRouter = require('./routes');

const app = express();

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 * 8 },
}));

// Static
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, '..', 'client')));

// API
app.use('/api', apiRouter);

// Fallback to login page
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, '..', 'client', 'index.html')));

// Error handler
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

init().then(() => {
  app.listen(PORT, () => console.log(`SIMS server running at http://localhost:${PORT}`));
}).catch(err => {
  console.error('DB init failed:', err);
  process.exit(1);
});
