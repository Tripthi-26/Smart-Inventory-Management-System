// Application configuration constants
module.exports = {
  PORT: process.env.PORT || 3000,
  SESSION_SECRET: process.env.SESSION_SECRET || 'sims-super-secret-change-me',
  DB_PATH: require('path').join(__dirname, '..', 'database', 'sims.db'),
  UPLOAD_DIR: require('path').join(__dirname, '..', 'uploads'),
};
